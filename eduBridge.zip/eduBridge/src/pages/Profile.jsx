import React from 'react'
import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import Button from '../components/Button'

const Profile = () => {
   

  const {userId}  = useParams();
  const [userData , setUserData] = useState(null);
  const [activeTab , setActiveTab] = useState('posts');
  const [posts , setPosts] = useState([]);


  useEffect(()=>{
    fetch(`http://localhost:5000/api/user/${userId}`)
    .then(res => res.json())
    .then(data => setUserData(data));


    fetch(`http://localhost:5000/api/posts/${userId}`)
    .then(res => res.json())
    .then(data=>setPosts(data))
  },[userId]);

  const renderPosts = (type) => {
    const filtered = posts.filter(post => post.type === type) || [];
    return (
      <div className="grid grid-cols-3 gap-2 mt-4">
        {filtered.map((post, index) => (
          <img
            key={index}
            src={post.imageUrl || '/placeholder.png'}
            alt="Post"
            className="w-full h-40 object-cover rounded-md"
          />
        ))}
      </div>
    );
  };

    
  return (
    <div className='bg-black text-white min-h-screen p-4 md:px-20'>
      <div className='flex flex-col md:flex-row items center md:items-start gap-6'>
        <img src={userData?.profilePic || 'default-profile.jpg'} alt="Profile" className='w-32 h-32 rounded-full border-2 border-white'/>
        <div className='text-center md:text-left'>
          <h2 className='text-xl font-semibold'>{userData?.username || localStorage.getItem("username")}</h2>
          <p className='text-gray-400'>{userData?.bio || 'No bio yet.'}</p>
          <div className='flex justify-center md:justify-start gap-4 mt-2'>
            <span>{posts?.length || 0} posts</span>
            <span>{userData?.followers || 0} Followers</span>
            <span>{userData?.following || 0} Following</span>
          </div>

          <div mt-4>
           <Link to="/editprofile"> <Button text="Edit Profile" className='bg-gray-700 px-4 py-1 rounded text-white hover:bg-gray-600 mt-3'/></Link>
          </div>
        </div>
      </div>
      <div className='flex justify-center md:justify-start gap-6 mt-6 border-b border-gray-700 pb-2'>
       <button onClick={()=>setActiveTab("posts")} className={activeTab === 'posts' ? "text-blue-400 font-semibold ": ""}>Posts</button>
       <button onClick={()=>setActiveTab("Buy")} className={activeTab === 'Buy' ? "text-blue-400 font-semibold ": ""}>Buy</button>
       <button onClick={()=>setActiveTab("Sell")} className={activeTab === 'Sell' ? "text-blue-400 font-semibold ": ""}>Sell</button>
      </div>

      <div className='mt-4'>
        {activeTab === 'posts' && renderPosts('note')}
        {activeTab === 'buy' && renderPosts('buy')}
        {activeTab === 'sell' && renderPosts('sell')}
      </div>
    </div>
  )
}

export default Profile