import React from 'react'
import { Link } from 'react-router-dom'
const Aside = () => {
  return (
    <div className='flex h-screen overflow-hidden'>
      <aside className='w-[300px] bg-black text-white sticky top-0 h-screen border-r border-gray-700-'>
        <div className='text-5xl text-center mt-6 text-white font-soul font-bold '>
          Edugram
        </div>

              <ul className="space-y-4 mt-9 px-6 text-xl">
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>🏠</span>
            <Link to="/home">Home</Link>
          </li>
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>🔍</span>
            <span>Search</span>
          </li>
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>📚</span>
            <span>Notes</span>
          </li>
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>💬</span>
            <span>Messages</span>
          </li>
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>🔔</span>
            <span>Notifications</span>
          </li>
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>➕</span>
            <span>Upload Yours</span>
          </li>
          <li className="flex items-center space-x-4 p-2 hover:bg-gray-800 rounded-lg cursor-pointer">
            <span>👤</span>
            <Link to="/profile/:userId">Profile</Link>
          </li>
        </ul>
 <div className="absolute bottom-6 px-6 w-full">
          <ul className="space-y-2 text-lg">
            <li className="hover:bg-gray-800 p-2 rounded cursor-pointer">Meta AI</li>
            <li className="hover:bg-gray-800 p-2 rounded cursor-pointer">AI Studio</li>
            <li className="hover:bg-gray-800 p-2 rounded cursor-pointer">More</li>
          </ul>
        </div>
      </aside>

    </div>
  )
}

export default Aside