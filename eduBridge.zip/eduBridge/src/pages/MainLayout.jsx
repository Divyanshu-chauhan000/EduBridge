import React from 'react'
import Aside from './Aside'
import { Outlet } from 'react-router-dom'
import RightAside from '../components/RightAside'
const MainLayout = () => {
  return (
    <div className='flex bg-black'>
      <Aside className="fixed left-0 top-0 h-screen w-[300px] z-50 border-r border-gray-700"/>
      <div className='flex-1 bg-black text-white h-screen overflow-y-scroll scrollbar-hide'>
          <Outlet/>
      </div>
      <RightAside className="fixed right-0 top-0 h-screen w-[350px] border-l border-gray-700 overflow-y-auto scrollbar-hide"/>
    </div>
  )
}

export default MainLayout