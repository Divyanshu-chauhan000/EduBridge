import React,{useEffect , useState} from 'react'
import {useParams , useNavigate} from 'react-router-dom'
const ProfileEdit = () => {

  const{userId} = useParams();
  const navigate = useNavigate();

  const [ form , setForm] = useState({
    fullName: '',
    userName: '',
    bio: '',
    college: '',
    degree: '',
    branch: '',
    year: '',
    skills: '',
    profilePic: ''
  });

  useEffect(()=>{
    fetch(`http://localhost:5000/api/user/${userId}`)
    .then(res => res.json())
    .then(data =>{
      setForm({
        fullName: data.fullName || '',
          userName: data.username || '',
          bio: data.bio || '',
          college: data.college || '',
          degree: data.degree || '',
          branch: data.branch || '',
          year: data.year || '',
          skills: data.skills?.join(', ') || '',
          profilePic: data.profilePic || ''
      });
    })
  },[userId])

  const handleChange = (e) =>{
    setForm({...form, [e.target.name]: e.target.value})
  }

  const handleSubmit = (e) =>{
    e.prevent.default();

    const updateData = {
      ...form,
      skills: form.skills.split(',').map(skill => skill.trim())
    };

    fetch(`http://localhost:5000/api/user/${userId}`,{
      method: 'PUT',
      headers: {'Content-Type' : "application/json"},
      body: JSON.stringify(updateData)
    })
    .then(res => res.json())
    .then(()=> navigate(`/profile/${userId}`))
  }

  return (
    <div className='min-h-screen bg-black text-white flex justify-center items-center p-6'>
      <form action="" onSubmit={handleSubmit} className='bg-gray-800 p-6 rounded-lg w-full max-w-xl space-y-4'>
        <h2 className='text-2xl font-semibold mb-4'>Edit Student Profile</h2>
          <input name='fullName' value={form.fullName} onChange={handleChange} placeholder='Full Name' className='w-full p-2 bg-gray-700 rounded'/>
          <input name='userName' value={form.userName} onChange={handleChange} placeholder=' Username' className='w-full p-2 bg-gray-700 rounded'/>

          <textarea name='bio' value={form.bio} placeholder='Bio' className='w-full p-2 bg-gray-700 rounded' onChange={handleChange}/>
           
          <input name='college' value={form.college} onChange={handleChange} placeholder='College' className='w-full p-2 bg-gray-700 rounded'/>

          <div className='flex gap-4 '>
           <select name="degree" onChange={handleChange} value={form.degree} className='w-full p-2 bg-gray-700 rounded'>
            <option value="">Select Degree</option>
            <option value="B.Tech">B.Tech</option>
            <option value="B.Sc">B.Sc</option>
            <option value="BCA">BCA</option>
            <option value="M.Tech">M.Tech</option>
           </select>

           <select name="year" onChange={handleChange} value={form.year} className='w-full p-2 bg-gray-700 rounded'>
            <option value="">Select Year</option>
            <option value="B.Tech">1st</option>
            <option value="B.Sc">2nd</option>
            <option value="BCA">3rd</option>
            <option value="M.Tech">4th</option>
           </select>
          </div>

          <input name='branch' value={form.branch} onChange={handleChange} placeholder='Branch' className='w-full p-2 bg-gray-700 rounded'/>


          <input name='skills' value={form.skills} onChange={handleChange} placeholder='Skills' className='w-full p-2 bg-gray-700 rounded'/>


          <input name='profilePic' value={form.profilePic} onChange={handleChange} placeholder='Profile Picture Url' className='w-full p-2 bg-gray-700 rounded'/>

          <button type='submit' className="bg-blue-600 px-4 py-2 rounded w-full hover:bg-blue-700" >Save</button>

          
      </form>

    </div>
  )
}

export default ProfileEdit