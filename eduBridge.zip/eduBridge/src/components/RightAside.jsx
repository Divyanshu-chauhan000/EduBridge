import React from 'react'
import { useState , useEffect } from 'react'
const RightAside = () => {

const [suggestions, setSuggestions] = useState([])

useEffect(() => {
      setSuggestions([
      {
        id: 1,
        username: "study_buddy_101",
        name: "Study Buddy",
        avatar: "/placeholder.svg?height=32&width=32",
        mutualFriends: "Followed by math_tutor_raj",
      },
      {
        id: 2,
        username: "notes_exchange",
        name: "Notes Exchange",
        avatar: "/placeholder.svg?height=32&width=32",
        mutualFriends: "Suggested for you",
      },
      {
        id: 3,
        username: "exam_prep_guru",
        name: "Exam Prep Guru",
        avatar: "/placeholder.svg?height=32&width=32",
        mutualFriends: "Followed by physics_notes_pro",
      },
      {
        id: 4,
        username: "book_reviews_edu",
        name: "Book Reviews",
        avatar: "/placeholder.svg?height=32&width=32",
        mutualFriends: "Suggested for you",
      },
    ])
  }, [])
  return (
    <div>
      <aside className='w-[350px] bg-black text-white p-6 sticky top-0 h-screen overflow-y-auto'>
         <div className='flex items-center justify-between mb-6'>
            <div className='flex items-center space-x-3'>
                <img src="/placeholder.svg?height=56&width=56" alt="Your Profile" className='w-14 h-14 rounded-full object-cover'/>

                <div>
                  <div className='font-semibold'>
                       {localStorage.getItem("username") || "Student_user"}
                  </div>
                  <div className='text-gray-400 text-sm'>
                       Student
                  </div>
                </div>
            </div>
            <button className='text-blue-500 text-sm'>Switch</button>
         </div>


         <div>
          <div className='flex items-center justify-between mb-4'>
           <span className='text-gray-400 font-semibold '>Suggested For You</span>
           <button className='text-white text-sm'>See All</button>
          </div>

          <div className='space-y-3'>
           {suggestions.map((suggestion) => (
              <div key={suggestion.id} className='flex items-center justify-between'>
                <div className='flex items-center space-x-3'>
                   <img src={suggestion.avatar || "/placeholder.svg"} alt={suggestion.username} className='w-8 h-8 rounded-full object-cover' />
                   <div>
                    <div className='font-semibold text-sm' >{suggestion.username}</div>
                    <div className='text-gray-400 text-xs '>{suggestion.mutualFriends}</div>
                   </div>
                </div>
                <button className='text-blue-500 text-sm font-semibold'>Follow</button>
              </div>
           ))}
          </div>
         </div>


         <div className='mt-8 text-xs text-gray-500 space-y-1'>
                  <div className='flex flex-wrap grap-3'>
                   <span>About</span>•<span>Help</span>•<span>Press</span>•<span>API</span>•<span>Jobs</span>•
                        <span>Privacy</span>•<span>Terms</span>
                  </div>

                  <div className='flex flex-wrap gap-2'>
                             <span>Locations</span>•<span>Language</span>•<span>Meta Verified</span>
                  </div>
                  <div className='mt-4'>© 2025 EDUGRAM FROM META</div>
         </div>
      </aside>
    </div>
  )
}

export default RightAside